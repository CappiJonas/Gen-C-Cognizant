﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading;

namespace Cognizant.Training.Rpa
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            //Opções do Chrome
            var chromeOptions = new ChromeOptions()
            {
                AcceptInsecureCertificates = true,
            };

            //Inicializa o driver do chrome
            var driver = new ChromeDriver(Environment.CurrentDirectory, chromeOptions, TimeSpan.FromSeconds(10));

            //Navega para a URL indicada
            driver.Url = "https://www.google.com.br";

            //Tira um print e armazena como base64
            var imagem = driver.GetScreenshot().AsBase64EncodedString;

            //Encontra o campo de pesquisa
            var campoDePesquisa = driver.FindElement(By.Name("q"));

            //Digita o termo de busca
            campoDePesquisa.SendKeys("Cognizant Brasil");

            //Aguarda 2 segundos para clicar no elemento
            Thread.Sleep(2000);

            //Encontra o botão de pesquisa
            var botaoDePesquisa = driver.FindElement(By.Name("btnK"));

            //Clica no botão de pesquisar
            botaoDePesquisa.Click();

            ReadOnlyCollection<IWebElement> resultados;

            //Loop para pegar os primeiros 5 resultados
            for (int i = 0; i < 5; i++)
            {
                resultados = driver.FindElements(By.ClassName("rc"));

                //Clica no resultado
                resultados[i].FindElement(By.TagName("a")).Click();

                //Aguarda 5 segundos para a página carregar
                Thread.Sleep(5000);

                //Tira o print da página
                var imagemResultado = driver.GetScreenshot().AsByteArray;

                //Salva o print em uma imagem
                File.WriteAllBytes(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + $"\\resultado{i}.jpg", imagemResultado);

                //Volta para a página anterior
                driver.Navigate().Back();

                //Aguarda 5 segundos para a página carregar
                Thread.Sleep(5000);
            }

            //Encerra o chrome
            driver.Close();
        }
    }
}