﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encapsulamento_Abstração
{
    public abstract class Poligono
    {
        protected abstract double Area();
    }
}
